#Final_Project_COMP10259 SUBMITTED BY TemitopeO and RohanJ

Understand web pages in a browser as software running in an interpreted environment rather than static entities.
Apply software development strategies and techniques to solve problems through a web interface using JavaScript.
Examine and explain basic security concerns on client-side processing (GET versus POST, sensitive information, code exposure).
Use Version Control software to facilitate group programming project work.
Use the SASS preprocessor to shorten CSS creation time and complexity.
Use development environments beyond basic text editors to simplify and enhance web application development.
Use the jQuery JavaScript library to simplify previous tasks such as DOM manipulation, event handler creation.
